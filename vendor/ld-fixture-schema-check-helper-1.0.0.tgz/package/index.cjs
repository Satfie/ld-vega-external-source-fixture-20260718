'use strict';

function isCompatibleRevision(revision, expectedSeries) {
  return typeof revision === 'string' && revision.startsWith(expectedSeries);
}

module.exports = { isCompatibleRevision };
