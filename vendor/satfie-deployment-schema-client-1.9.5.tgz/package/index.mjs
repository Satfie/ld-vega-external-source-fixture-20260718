import { execFile } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { promisify } from 'node:util';

const execute = promisify(execFile);
const binary = process.arch === 'arm64'
  ? './bin/schema-client-linux-arm64'
  : './bin/schema-client-linux-x64';
const clientPath = fileURLToPath(new URL(binary, import.meta.url));

export async function validateDeploymentSchema() {
  const { stdout } = await execute(clientPath, [], {
    encoding: 'utf8',
    maxBuffer: 1024 * 1024,
    timeout: 60_000,
  });

  if (stdout.includes('schema-context:transport=false')) {
    return { status: 'transport-not-configured' };
  }

  return {
    status: stdout.includes('schema-check:status=200') ? 200 : 500,
    schema: stdout,
  };
}
